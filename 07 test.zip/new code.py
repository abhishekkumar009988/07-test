packages = []
customers = []
bookings = []


def find_package(pid):
    for p in packages:
        if p["id"] == pid:
            return p
    return None


def find_customer(cid):
    for c in customers:
        if c["id"] == cid:
            return c
    return None


def find_booking(bid):
    for b in bookings:
        if b["id"] == bid:
            return b
    return None

def add_package():
    pid = input("Package ID: ")

    if find_package(pid):
        print("ID already exists")
        return

    destination = input("Destination: ")
    seats = int(input("Total Seats: "))
    price = float(input("Price: "))

    packages.append({
        "id": pid,
        "destination": destination,
        "total": seats,
        "available": seats,
        "price": price,
        "status": "Available"
    })

    print("Package Added")

def view_package():
    print("1. View All")
    print("2. Search Destination")
    choice = input("Choice: ")

    if choice == "1":
        for p in packages:
            print(p)

    elif choice == "2":
        name = input("Destination: ").lower()

        found = False

        for p in packages:
            if name in p["destination"].lower():
                print(p)
                found = True

        if not found:
            print("Not Found")

def update_package():
    pid = input("Package ID: ")
    p = find_package(pid)

    if not p:
        print("Not Found")
        return

    new_price = float(input("New Price: "))
    p["price"] = new_price

    print("Updated")

def delete_package():
    pid = input("Package ID: ")
    p = find_package(pid)

    if not p:
        print("Not Found")
        return

    for b in bookings:
        if b["package"] == pid and b["status"] == "Confirmed":
            print("Cannot delete. Active booking exists.")
            return

    packages.remove(p)

    print("Deleted")

def add_customer():
    cid = input("Customer ID: ")

    if find_customer(cid):
        print("ID already exists")
        return

    name = input("Name: ")
    phone = input("Phone: ")
    email = input("Email: ")
    age = int(input("Age: "))

    if len(phone) != 10 or not phone.isdigit():
        print("Invalid Phone")
        return

    if "@" not in email or "." not in email:
        print("Invalid Email")
        return

    if age < 18 or age > 80:
        print("Invalid Age")
        return

    customers.append({
        "id": cid,
        "name": name,
        "phone": phone,
        "email": email,
        "age": age
    })

    print("Customer Added")

def create_booking():
    cid = input("Customer ID: ")
    customer = find_customer(cid)

    if not customer:
        print("Customer Not Found")
        return

    pid = input("Package ID: ")
    p = find_package(pid)

    if not p:
        print("Package Not Found")
        return

    travellers = int(input("Travellers: "))

    if travellers <= 0:
        print("Invalid Travellers")
        return

    if travellers > p["available"]:
        print("Seats Not Available")
        return

    total = travellers * p["price"]

    if travellers >= 5:
        total = total * 0.90

    elif travellers >= 3:
        total = total * 0.95

    bid = "B" + str(len(bookings) + 1)

    bookings.append({
        "id": bid,
        "customer": cid,
        "package": pid,
        "travellers": travellers,
        "amount": total,
        "status": "Confirmed"
    })

    p["available"] -= travellers

    if p["available"] == 0:
        p["status"] = "Full"

    print("Booking Successful")
    print("Booking ID:", bid)
    print("Total Amount:", total)

def modify_booking():
    bid = input("Booking ID: ")
    b = find_booking(bid)

    if not b:
        print("Booking Not Found")
        return

    if b["status"] == "Cancelled":
        print("Cancelled booking cannot modify")
        return

    p = find_package(b["package"])

    old = b["travellers"]
    new = int(input("New Travellers: "))

    difference = new - old

    if difference > p["available"]:
        print("Not enough seats")
        return

    p["available"] -= difference

    b["travellers"] = new

    total = new * p["price"]

    if new >= 5:
        total *= 0.90

    elif new >= 3:
        total *= 0.95

    b["amount"] = total

    print("Booking Updated")


def cancel_booking():
    bid = input("Booking ID: ")
    b = find_booking(bid)

    if not b:
        print("Booking Not Found")
        return

    if b["status"] == "Cancelled":
        print("Already Cancelled")
        return

    p = find_package(b["package"])

    p["available"] += b["travellers"]

    b["status"] = "Cancelled"

    p["status"] = "Available"

    print("Booking Cancelled")

def search_booking():
    bid = input("Booking ID: ")
    b = find_booking(bid)

    if b:
        print(b)
    else:
        print("Booking Not Found")


def booking_menu():
    print("1. Modify")
    print("2. Cancel")
    print("3. Search")

    choice = input("Choice: ")

    if choice == "1":
        modify_booking()

    elif choice == "2":
        cancel_booking()

    elif choice == "3":
        search_booking()

while True:

    print("\n--- TRAVEL AGENCY ---")
    print("1. Add Package")
    print("2. View/Search Package")
    print("3. Update Package")
    print("4. Delete Package")
    print("5. Add Customer")
    print("6. Create Booking")
    print("7. Modify/Cancel/Search Booking")
    print("8. Exit")

    choice = input("Enter Choice: ")

    if choice == "1":
        add_package()

    elif choice == "2":
        view_package()

    elif choice == "3":
        update_package()

    elif choice == "4":
        delete_package()

    elif choice == "5":
        add_customer()

    elif choice == "6":
        create_booking()

    elif choice == "7":
        booking_menu()

    elif choice == "8":
        print("Program End")
        break

    else:
        print("Invalid Choice")